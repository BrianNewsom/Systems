//
// 15 problems, 40 points
// 2 - rating 1
// 3 - rating 2
// 7 - rating 3
// 3 - rating 4

// rating 1
int isZero(int);
int test_isZero(int);
int bitAnd(int, int);
int test_bitAnd(int, int);
// rating 2
int fitsBits(int, int);
int test_fitsBits(int, int);
int getByte(int, int);
int test_getByte(int, int);
int isNotEqual(int, int);
int test_isNotEqual(int, int);
int bitXor(int, int);
int test_bitXor(int, int);
int copyLSB(int);
int test_copyLSB(int);
// rating 3
int sum3(int, int, int);
int test_sum3(int, int, int);
int reverseBytes(int);
int test_reverseBytes(int);
int isNegative(int);
int test_isNegative(int);
int isLess(int, int);
int test_isLess(int, int);
// rating 4
int isNonZero(int);
int test_isNonZero(int);
int bitCount(int);
int test_bitCount(int);
int bang(int);
int test_bang(int);
int bitParity(int);
int test_bitParity(int);
